﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace Luis
{
    public class LUISClient
    {
        public static async Task<LUISResponse> ParseUserInput(string strInput)
        {
            string strRet = string.Empty;
            string strEscaped = Uri.EscapeDataString(strInput);

            using (var client = new HttpClient())
            {
                string uri= "https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/9683cd94-5984-4e67-91c9-bd141abc6b64?subscription-key=2f8c4884e1a54d4f832f386d3a6dadd3&verbose=true&timezoneOffset=-300&q= " + strEscaped;
                HttpResponseMessage msg = await client.GetAsync(uri);

                if (msg.IsSuccessStatusCode)
                {
                    var jsonResponse = await msg.Content.ReadAsStringAsync();
                    var _Data = JsonConvert.DeserializeObject<LUISResponse>(jsonResponse);
                    return _Data;
                }
            }
            return null;
        }
    }

    public class LUISResponse
    {
        public string Query { get; set; }
        public lIntent[] Intents { get; set; }
        public lEntity[] Entities { get; set; }
    }

    public class lIntent
    {
        public string Intent { get; set; }
        public float Score { get; set; }
    }

    public class lEntity
    {
        public string Entity { get; set; }
        public string Type { get; set; }
        public int StartIndex { get; set; }
        public int EndIndex { get; set; }
        public float Score { get; set; }
    }
}