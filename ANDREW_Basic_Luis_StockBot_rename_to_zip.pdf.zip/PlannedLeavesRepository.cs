﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Basic_Luis_StockBot
{
    public class PlannedLeavesRepository
    {
        public int GetCount(string username)
        {
            switch(username)
            {
                case "akanieski":
                    return 18;
                case "snaidu":
                    return 3;
            }
            throw new Exception("Username not found");
        }
    }
}